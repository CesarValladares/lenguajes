### Proyecto final
## Lenguajes de programación  
## César Armando Valladares Martínez 
## A01023506

- Este proyecto consta de 4 funciones

1. Genera una imagen negativa de la original
2. Genera una imagen mas obscura que la original 
3. Genera una imagen mas brillante que la original 
4. Aplica el filtro blur a una image

- Para ejecutar las funciones solo es necesario ejecutar la función "main" 
- Los nombres de las imagenes ya estan dentro del código y se mandan a llamar las otras 4 funciones
- Cada nueva imagen se guarda con el nombre de la función que se le aplico 

# Referencias 
https://docs.racket-lang.org/teachpack/2htdpimage.html
https://docs.racket-lang.org/picturing-programs/index.html
https://docs.racket-lang.org/teachpack/image.html
 
 